### 12.	Create two sets: [5]
##set1 = {20, 40, 60}
##set2 = {10, 20, 30, 40, 50, 60}
##(a) Write code to perform a union of these sets. Print the length of the resulting set.
##(b) Write code to perform an intersection of set1 and set2.
##(c) Write code to compute the symmetric difference between set1 and set2
##(d) Write code to add the value 40 to set1, did the set change?
##(e) Write code to remove value 20 from set2.

'''
This program performs various set operations on two sets, set1 and set2.
'''


set1 = {20, 40, 60}
set2 = {10, 20, 30, 40, 50, 60}

# (a) Perform a union of these sets and print the length of the resulting set
union_set = set1 | set2
print("Union of sets:", union_set)
print("Length of the union set:", len(union_set))

# (b) Perform an intersection of set1 and set2
intersection_set = set1 & set2
print("Intersection of sets:", intersection_set)

# (c) Compute the symmetric difference between set1 and set2
symmetric_diff_set = set1 ^ set2
print("Symmetric difference between sets:", symmetric_diff_set)

# (d) Add the value 40 to set1, and check if the set changed
set1.add(40)
print("Set1 after adding 40:", set1)
# Since 40 is already in set1, the set does not change

# (e) Remove value 20 from set2
set2.remove(20)
print("Set2 after removing 20:", set2)

