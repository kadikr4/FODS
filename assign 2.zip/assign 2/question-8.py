# 8. Write a program that prompts the user to enter integer values to populate two lists, then prints messages to determine the following: [3]
##(a) Whether the lists are of the same length. 
##(b) Whether the elements in each list sum to the same value. 
##(c) Whether there are any values that occur in both lists

'''
This program prompts the user to enter integer values to populate two lists.
It then checks and prints:
(a) Whether the lists are of the same length.
(b) Whether the elements in each list sum to the same value.
(c) Whether there are any values that occur in both lists.
'''

def compare_lists():
    
    list1 = []
    list2 = []
    

    
    print("Enter integers for the first list (type 'done' to finish):")
    while True:
        value = input("Enter an integer (or type 'done' to finish): ")
        if value.lower() == 'done':
            break
        else:
            try:
                list1.append(int(value))
            except ValueError:
                print("Invalid input! Please enter an integer.")
    

    
    print("Enter integers for the second list (type 'done' to finish):")
    while True:
        value = input("Enter an integer (or type 'done' to finish): ")
        if value.lower() == 'done':
            break
        else:
            try:
                list2.append(int(value))
            except ValueError:
                print("Invalid input! Please enter an integer.")

    # (a) Check if the lists are the same length
    if len(list1) == len(list2):
        print("The lists are of the same length.")
    else:
        print("The lists are not of the same length.")
    
    # (b) Check if the elements in each list sum to the same value
    if sum(list1) == sum(list2):
        print("The sums of the elements in both lists are the same.")
    else:
        print("The sums of the elements in both lists are not the same.")
    
    # (c) Check if there are any common values between the lists
    common_values = set(list1).intersection(set(list2))
    if common_values:
        print(f"There are common values between the lists: {common_values}")
    else:
        print("There are no common values between the lists.")


compare_lists()


