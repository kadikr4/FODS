# Write a function that accepts a string and calculate the number of upper case letters and lower case letters.

'''
This program accepts a string from the user and calculates
the number of uppercase and lowercase letters in the string.
'''

def count_case_letters(text):
    upper = 0
    lower = 0
    for x in text:
        if x.isupper():
            upper += 1
        elif x.islower():
            lower += 1
    print("Number of uppercase letters:", upper)
    print("Number of lowercase letters:", lower)


user_input = input("Enter a string: ")
count_case_letters(user_input)


