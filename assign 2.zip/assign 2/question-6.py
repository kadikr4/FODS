# 5.	Write a program that prompts the user for a series of integers and stores in a list only the values between 1-100, and displays the resulting list.


'''
This program prompts the user for a series of integers and stores
only the values between 1 and 100 in a list, then displays the list.
'''

def filter_integers():
    
    valid_numbers = []
    
    while True:
        try:
            
            user_input = input("Enter an integer (or type 'done' to finish): ")
            
            if user_input.lower() == 'done':
                break
            
            num = int(user_input)
            
            
            if 1 <= num <= 100:
                valid_numbers.append(num)
            else:
                print("The number is not between 1 and 100. Try again.")
        except ValueError:
            print("Invalid input! Please enter an integer.")
    
    
    print("Numbers between 1 and 100:", valid_numbers)


filter_integers()
