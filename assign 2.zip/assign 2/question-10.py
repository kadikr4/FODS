#10.	Write a function named get_daily_temps that prompts the user for the average temperature for each day of the week and returns a dictionary containing the information the user entered


'''
This function, get_daily_temps, prompts the user for the average temperature for each day of the week 
and returns a dictionary containing the entered temperatures.
'''

def get_daily_temps():
    
    days_of_week = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
    
    
    temp_dict = {day: float(input(f"Enter the average temperature for {day}: ")) for day in days_of_week}
    
    return temp_dict


temperature_dict = get_daily_temps()
print("The temperatures for the week are:", temperature_dict)
