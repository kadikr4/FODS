#Write a program that prompts the user to enter a list of names and store them in a list. The program should display how many times the letter 'a appears within the list.

'''
This program prompts the user to enter a list of names, stores them in a list,
and counts how many times the letter 'a' appears in the entire list of names.
'''

def count_letter_a():
    
    names = []
    
    
    while True:
        name = input("Enter a name (or type 'done' to finish): ")
        
        if name.lower() == 'done':
            break
        names.append(name)
    
    
    count_a = 0
    for name in names:
        count_a += name.lower().count('a')  
    
    print("The letter 'a' appears", count_a, "times in the list of names.")


count_letter_a()
