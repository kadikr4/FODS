# 2.Write a function to check whether the given number is prime or not

'''
This program checks whether the given number is a prime number or not.
A prime number is a number greater than 1 that has no divisors other than 1 and itself.
'''

def is_prime(n):
    if n < 2:
        return False
    for i in range(2, n):
        if n % i == 0:
            return False
    return True

# Main program
num = int(input("Enter a number: "))

if is_prime(num):
    print(num, "is a prime number.")
else:
    print(num, "is not a prime number.")
