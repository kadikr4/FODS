# write a function to accept a list of names and return the sorted order of names back.


'''
This program accepts a list of names and returns the list sorted in alphabetical order.
'''

def sort_names(names):
    return sorted(names)

# Main program
name_list = input("Enter a list of names separated by commas: ").split(",")
sorted_names = sort_names(name_list)

print("Sorted names:", sorted_names)
