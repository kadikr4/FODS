##11.	Create three dictionaries: [7]
##dic1 = {1:10, 2:20}
##dic2 = {3:30, 4:40}
##dic3 = {5:50, 6:60}
##(a) Write code to concatenate these dictionaries to create a new one. Create a variable called nums to store the resulting dictionary. 
##
##(b) Write code to add a new key/value pair to the dictionary nums: (7, 70)
##(c) Write code to update the value of the item with key 3 in nums to 80
##(d) Write code to remove the third item from dictionary nums.
##(e) Write code to sum all the items in the dictionary nums
##(f) Write code to multiply all the items in the dictionary nums
##(g) Write code to retrieve the maximum and minimum values in nums.



'''
This program creates three dictionaries and performs a series of operations to manipulate them as described.
'''

# (a) Concatenate dictionaries dic1, dic2, and dic3 to create a new dictionary called nums.
dic1 = {1: 10, 2: 20}
dic2 = {3: 30, 4: 40}
dic3 = {5: 50, 6: 60}
nums = {**dic1, **dic2, **dic3}  

# (b) Add a new key/value pair (7, 70) to the dictionary nums
nums[7] = 70

# (c) Update the value of the item with key 3 in nums to 80
nums[3] = 80

# (d) Remove the third item from the dictionary nums
del list(nums.items())[2]

# (e) Sum all the items in the dictionary nums (sum of values)
sum_values = sum(nums.values())

# (f) Multiply all the items in the dictionary nums (product of values)
from functools import reduce
import operator
product_values = reduce(operator.mul, nums.values(), 1)

# (g) Retrieve the maximum and minimum values in nums
max_value = max(nums.values())
min_value = min(nums.values())


print("Concatenated Dictionary:", nums)
print("Sum of values:", sum_values)
print("Product of values:", product_values)
print("Maximum value:", max_value)
print("Minimum value:", min_value)
