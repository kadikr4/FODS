
# 13.	Create a function called word_intersection that prompts the user for two English words, and displays which letters the two words have in common. [3]


'''
This function prompts the user for two English words and displays the letters they have in common.
'''

def word_intersection():
    
    word1 = input("Enter the first word: ")
    word2 = input("Enter the second word: ")
    
    
    common_letters = set(word1) & set(word2)
    
   
    if common_letters:
        print(f"The common letters are: {', '.join(common_letters)}")
    else:
        print("There are no common letters.")



word_intersection()
