# 9.	Write a function called add_daily_temp that is given a (possibly empty) dictionary meant to hold the average daily temperature for each day of the week, a temperature value, and the day of the week for the recorded temperature. The function should then add the temperature to the dictionary only if it does not already contain a temperature for that day. The function should return the resulting dictionary, whether it is updated or not.


'''
This function, add_daily_temp, takes a dictionary representing the average daily temperatures for each day of the week,
a temperature value, and the day of the week for the recorded temperature.
It adds the temperature to the dictionary only if the dictionary does not already contain a temperature for that day.
The function then returns the resulting dictionary.
'''

def add_daily_temp(temp_dict, temp, day):
   
    if day not in temp_dict:
        temp_dict[day] = temp  
    else:
        print(f"Temperature for {day} already exists.")
    
    
    return temp_dict


temperature_dict = {}
temperature_dict = add_daily_temp(temperature_dict, 72, 'Monday')
temperature_dict = add_daily_temp(temperature_dict, 75, 'Tuesday')
temperature_dict = add_daily_temp(temperature_dict, 70, 'Monday')  
print(temperature_dict)
