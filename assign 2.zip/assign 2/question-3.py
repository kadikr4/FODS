# 3.	Write a function to check whether the given number is Armstrong or not.

'''
This program checks whether the given number is an Armstrong number or not.
An Armstrong number is a number that is equal to the sum of its own digits each raised to the power of the number of digits.
'''

def is_armstrong(n):
    digits = str(n)
    power = len(digits)
    total = 0
    for d in digits:
        total += int(d) ** power
    return total == n

# Main program
num = int(input("Enter a number: "))

if is_armstrong(num):
    print(num, "is an Armstrong number.")
else:
    print(num, "is not an Armstrong number.")

