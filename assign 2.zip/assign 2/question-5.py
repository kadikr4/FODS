#5. Create a program called calculator with functions to perform the following arithmetic calculations, each should take two decimal parameters and return the result of the arithmetic calculation in question.[7]
##A. Addition
##B. Subtraction
##C. Multiplication
##D. Division
##E. Truncated division
##F. Modulus
##G. Exponentiation



'''
This program performs basic arithmetic operations: 
Addition, Subtraction, Multiplication, Division, 
Truncated Division, Modulus, and Exponentiation.
Each function takes two decimal numbers and returns the result.
'''

def add(a, b):
    return a + b

def subtract(a, b):
    return a - b

def multiply(a, b):
    return a * b

def divide(a, b):
    if b != 0:
        return a / b
    else:
        return "Error: Division by zero"

def truncated_division(a, b):
    if b != 0:
        return a // b
    else:
        return "Error: Division by zero"

def modulus(a, b):
    if b != 0:
        return a % b
    else:
        return "Error: Division by zero"

def exponentiate(a, b):
    return a ** b


print("Welcome to the calculator program!")


num1 = float(input("Enter the first number: "))
num2 = float(input("Enter the second number: "))


print(f"Addition: {add(num1, num2)}")
print(f"Subtraction: {subtract(num1, num2)}")
print(f"Multiplication: {multiply(num1, num2)}")
print(f"Division: {divide(num1, num2)}")
print(f"Truncated Division: {truncated_division(num1, num2)}")
print(f"Modulus: {modulus(num1, num2)}")
print(f"Exponentiation: {exponentiate(num1, num2)}")
