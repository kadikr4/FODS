# Write a program to implement a class called employee with attributes such as empid, name, address, contact_number, spouse name, number_of_child, salary. Instantiate this class to input the values for multiple employees and write it in a file “employees.csv”. Allow the user of your program to see the list of employees and their details as well. Try to use the concept of try/except too in the program. [20 marks]


'''This program defines an Employee class to store employee details,
takes input for multiple employees, saves them to a CSV file named "employees.csv",
and displays all employee records. It uses try/except for basic error handling.'''

import csv

class Employee:
    def __init__(self, empid, name, address, contact_number, spouse_name, number_of_child, salary):
        self.empid = empid
        self.name = name
        self.address = address
        self.contact_number = contact_number
        self.spouse_name = spouse_name
        self.number_of_child = number_of_child
        self.salary = salary

    def get_data_as_list(self):
        return [self.empid, self.name, self.address, self.contact_number,
                self.spouse_name, self.number_of_child, self.salary]

def input_employee():
    try:
        empid = input("Enter Employee ID: ")
        name = input("Enter Name: ")
        address = input("Enter Address: ")
        contact_number = input("Enter Contact Number: ")
        spouse_name = input("Enter Spouse Name: ")
        number_of_child = int(input("Enter Number of Children: "))
        salary = float(input("Enter Salary: "))
        return Employee(empid, name, address, contact_number, spouse_name, number_of_child, salary)
    except ValueError:
        print("Invalid input! Please enter correct data types.")
        return None

def write_employees_to_csv(employees):
    try:
        with open("employees.csv", mode="w", newline="") as file:
            writer = csv.writer(file)
            writer.writerow(["EmpID", "Name", "Address", "Contact", "Spouse", "Children", "Salary"])
            for emp in employees:
                writer.writerow(emp.get_data_as_list())
        print("Data written to employees.csv successfully.")
    except Exception as e:
        print("Error writing to file:", e)

def display_employees(employees):
    print("\nEmployee List:")
    for emp in employees:
        print(f"ID: {emp.empid}, Name: {emp.name}, Address: {emp.address}, Contact: {emp.contact_number}, "
              f"Spouse: {emp.spouse_name}, Children: {emp.number_of_child}, Salary: {emp.salary}")


employees = []

while True:
    print("\nEnter details for a new employee:")
    emp = input_employee()
    if emp:
        employees.append(emp)

    more = input("Do you want to add another employee? (yes/no): ")
    if more.lower() != "yes":
        break

write_employees_to_csv(employees)
display_employees(employees)
