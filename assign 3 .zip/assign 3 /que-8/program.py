# 8.Write a program to implement a basic library book management with the functionalities such as issue the book, return the book and search the book. Use the concept of OOP to create the necessary classes on your own and implement the concept of other OOP features. For the storage of book details, use the file handling along with the exception handling.


'''This program implements a basic library book management system using OOP.
It allows the user to issue a book, return a book, and search for a book.
Book details are saved in a text file using file handling and exception handling.'''

import os

class Book:
    def __init__(self, book_id, title, author, available=True):
        self.book_id = book_id
        self.title = title
        self.author = author
        self.available = available

    def to_string(self):
        return f"{self.book_id},{self.title},{self.author},{self.available}"

    @staticmethod
    def from_string(data):
        book_id, title, author, available = data.strip().split(",")
        return Book(book_id, title, author, available == "True")

class Library:
    def __init__(self, filename="books.txt"):
        self.filename = filename
        self.books = []
        self.load_books()

    def load_books(self):
        try:
            if os.path.exists(self.filename):
                with open(self.filename, "r") as file:
                    for line in file:
                        self.books.append(Book.from_string(line))
        except Exception as e:
            print("Error loading books:", e)

    def save_books(self):
        try:
            with open(self.filename, "w") as file:
                for book in self.books:
                    file.write(book.to_string() + "\n")
        except Exception as e:
            print("Error saving books:", e)

    def add_book(self, book):
        self.books.append(book)
        self.save_books()

    def issue_book(self, book_id):
        for book in self.books:
            if book.book_id == book_id and book.available:
                book.available = False
                self.save_books()
                print(f"Book '{book.title}' issued successfully.")
                return
        print("Book not available or not found.")

    def return_book(self, book_id):
        for book in self.books:
            if book.book_id == book_id and not book.available:
                book.available = True
                self.save_books()
                print(f"Book '{book.title}' returned successfully.")
                return
        print("Book not found or already available.")

    def search_book(self, keyword):
        found = False
        for book in self.books:
            if keyword.lower() in book.title.lower() or keyword.lower() in book.author.lower():
                status = "Available" if book.available else "Issued"
                print(f"[{book.book_id}] {book.title} by {book.author} - {status}")
                found = True
        if not found:
            print("No matching books found.")


library = Library()

while True:
    print("\n--- Library Menu ---")
    print("1. Add New Book")
    print("2. Issue Book")
    print("3. Return Book")
    print("4. Search Book")
    print("5. Exit")

    choice = input("Enter your choice (1-5): ")

    if choice == "1":
        book_id = input("Enter Book ID: ")
        title = input("Enter Title: ")
        author = input("Enter Author: ")
        new_book = Book(book_id, title, author)
        library.add_book(new_book)
        print("Book added successfully.")
    elif choice == "2":
        book_id = input("Enter Book ID to issue: ")
        library.issue_book(book_id)
    elif choice == "3":
        book_id = input("Enter Book ID to return: ")
        library.return_book(book_id)
    elif choice == "4":
        keyword = input("Enter keyword to search: ")
        library.search_book(keyword)
    elif choice == "5":
        print("Exiting the program.")
        break
    else:
        print("Invalid choice. Please try again.")
