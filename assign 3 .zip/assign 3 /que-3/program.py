# 3. Write a program to find and replace a specific word in a file with another word.[10 marks]

'''Program to find and replace a specific word in a file with another word'''

def find_replace(filename, old_word, new_word):
    try:
        with open(filename, 'r') as file:
            content = file.read()
        
        
        new_content = content.replace(old_word, new_word)
        
        
        with open(filename, 'w') as file:
            file.write(new_content)
        
        print(f"'{old_word}' has been replaced with '{new_word}' in the file.")
    
    except FileNotFoundError:
        print("File not found.")


find_replace('python is love.txt', 'Python', 'Java')
