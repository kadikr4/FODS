# 5.Develop a program that counts the occurrence of each word in a file.

'''Program to count the occurrence of each word in a file'''

import string

def count_word_occurrences(filename):
    try:
        with open(filename, 'r') as file:
            content = file.read().lower()  
            
            
            content = content.translate(str.maketrans('', '', string.punctuation))
            
            
            words = content.split()
            
            
            word_count = {}
            for word in words:
                if word in word_count:
                    word_count[word] += 1
                else:
                    word_count[word] = 1
            
            
            for word, count in word_count.items():
                print(f"{word}: {count}")
    
    except FileNotFoundError:
        print("File not found.")


count_word_occurrences('about.txt')
