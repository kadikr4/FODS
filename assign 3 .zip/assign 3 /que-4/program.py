# 4. Implement a program to read a CSV file and display its contents in a tabular format.[10 marks]

'''Program to read a CSV file and display its content in tabular format'''

import csv

def display_csv(filename):
    try:
        with open(filename, 'r') as file:
            reader = csv.reader(file)
           
            for row in reader:
                print('\t'.join(row))
    
    except FileNotFoundError:
        print("File not found.")


display_csv('info.csv')
