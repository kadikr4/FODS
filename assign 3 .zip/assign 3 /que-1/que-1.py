#Write a program to count the number of lines, words, and characters in a text file.


'''Program to count lines, words, and characters in a file'''

def count_file_stats(filename):
    try:
        with open(filename, 'r') as file:
            lines = file.readlines()
            line_count = len(lines)
            word_count = sum(len(line.split()) for line in lines)
            char_count = sum(len(line) for line in lines)
        print(f"Lines: {line_count}, Words: {word_count}, Characters: {char_count}")
    except FileNotFoundError:
        print("File not found.")


count_file_stats('about.txt')



