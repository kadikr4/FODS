# 6. Create a class Student with the attributes such as id, name, address, admission year, level, section. Instantiate the object of class to take input for all the attributes and display the output.


'''Program to create a Student class with attributes and display the information'''

class Student:
    def __init__(self, student_id, name, address, admission_year, level, section):
        self.student_id = student_id
        self.name = name
        self.address = address
        self.admission_year = admission_year
        self.level = level
        self.section = section

    def display_info(self):
        print(f"Student ID: {self.student_id}")
        print(f"Name: {self.name}")
        print(f"Address: {self.address}")
        print(f"Admission Year: {self.admission_year}")
        print(f"Level: {self.level}")
        print(f"Section: {self.section}")


student_id = input("Enter Student ID: ")
name = input("Enter Student Name: ")
address = input("Enter Student Address: ")
admission_year = input("Enter Admission Year: ")
level = input("Enter Student Level (e.g., Undergraduate, Graduate): ")
section = input("Enter Student Section (e.g., A, B, C): ")


student = Student(student_id, name, address, admission_year, level, section)


print("\nStudent Information:")
student.display_info()
