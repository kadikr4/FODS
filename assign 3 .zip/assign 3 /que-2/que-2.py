# 2.	Write a program to copy the contents of one file to another


'''Program to copy contents from one file to another'''

def copy_file(source, destination):
    try:
        with open(source, 'r') as src, open(destination, 'w') as dest:
            dest.write(src.read())
        print("File copied successfully.")
    except FileNotFoundError:
        print("Source file not found.")

# Copy content from 'about.txt' to 'copy.txt'
copy_file('about.txt', 'copy.txt')
