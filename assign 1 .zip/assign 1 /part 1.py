'''
Description:
This program demonstrates how to evaluate several expressions in Python. 
It calculates the perimeter of a rectangle, performs string manipulations, 
evaluates mathematical expressions, and handles other data types like integers, floats, and Unicode encodings.
'''

# 1)The perimeter of a rectangle with length 9 & width 6
length = 9
width = 6
perimeter = 2 * (length + width)
print("Perimeter of the rectangle:", perimeter)
# 2)Python is great, it’s wild!
statement = "Python is great, it's wild!"
print(statement)
#3) 2 to the 10thpower
result = 2 ** 10
print("2 to the 10th power:", result)
#4) 7 factorial minus 5 factorial
import math
factorial_difference = math.factorial(7) - math.factorial(5)
print("7 factorial minus 5 factorial:", factorial_difference)

#5) Your forename multiplied by 5
forename = "adi"  
forename_repeated = forename * 5
print("Your forename multiplied by 5:", forename_repeated)
#6)Your name left justified 15 spaces
name = "Aditya"
left_justified_name = name.ljust(15)
print("Your name left justified 15 spaces:", left_justified_name)
#7)PI to 5 decimal places
import math
pi_value = round(math.pi, 5)
print("PI to 5 decimal places:", pi_value)
#8)200 modulus 12
modulus_result = 200 % 12
print("200 modulus 12:", modulus_result)
#9)7.2 as an integer value
integer_value = int(7.2)
print("7.2 as an integer value:", integer_value)
#10) The Unicode encoding for your name

unicode_encoding = [ord(char) for char in "Aditya"]
print("The Unicode encoding for your name:", unicode_encoding)
