# 1.Write a program to take a number input from the user and display whether the number is even or odd. [5]
'''This program takes a number as input and checks whether it is even or odd.'''

num = int(input("Enter a number: "))
if num % 2 == 0:
    print("Even")
else:
    print("Odd")
