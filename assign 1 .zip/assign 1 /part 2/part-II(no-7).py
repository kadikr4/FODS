# Write a Python program that accepts a string and calculates the number of digits and letters

'''This program counts the number of digits and letters in an input string.'''

text = input("Enter a string: ")
digits = letters = 0
for x in text:
    if x.isdigit():
        digits += 1
    elif x.isalpha():
        letters += 1
print("Letters:", letters)
print("Digits:", digits)
