#10.	Write a program to find the simple interest when the value of principle, rate of interest and time period is provided by the user.


'''This program calculates simple interest based on principal, rate, and time input from the user.'''

p = float(input("Enter principal: "))
r = float(input("Enter rate of interest: "))
t = float(input("Enter time (in years): "))
si = (p * r * t) / 100
print("Simple Interest:", si)
