# 3.Write a program that will convert Celsius value to Fahrenheit.


'''This program converts temperature from Celsius to Fahrenheit.'''

celsius = float(input("Enter temperature in Celsius: "))
fahrenheit = (celsius * 9/5) + 32
print("Temperature in Fahrenheit:", fahrenheit)
