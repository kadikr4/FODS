
#2. Write a program that prompts the user for two integer values and displays the results of the first number divided by the second, with exactly two decimal places displayed. [5]



'''This program takes two integers as input and displays the result of their division with two decimal places.'''

a = int(input("Enter first number: "))
b = int(input("Enter second number: "))
result = a / b
print("Result: {:.2f}".format(result))
