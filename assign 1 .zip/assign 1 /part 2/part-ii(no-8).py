### Write a program to create a number guessing game for the user. The program should ask the user to input a number. The program specifications are as mentioned below.
##I.	The program should generate a random number for the answer.[2.5]
##II.	The program should prompt the user for a number input.[2.5]
##III.	The program should provide the feedback to the user after each guesses (e.g. “Too high”, “Too low” or “Correct number”).[2.5]
##IV.	The program should check the user input for 5 times and allow the users to guess for at most 5 times if their input don’t match the answer number.[2.5]
##V.	If the user is not able to guess the answer within 5 times, the program should display “Game Over” message and exit. [5]


'''This program is a number guessing game where the user has 5 chances to guess the correct number.'''

import random

answer = random.randint(1, 100)
attempts = 0

while attempts < 5:
    guess = int(input("Guess the number (1-100): "))
    if guess == answer:
        print("Correct number!")
        break
    elif guess < answer:
        print("Too low")
    else:
        print("Too high")
    attempts += 1

if attempts == 5 and guess != answer:
    print("Game Over. The number was:", answer)
